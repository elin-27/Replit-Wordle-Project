#include <iostream>
#include "header.hpp"
using namespace std;

int main() 
{ 
  string entry;
  cout << "   Wordle\n"
       << "------------\n";
  cout << "   ";
  cin >> entry;
  cout << "   \x1b[100m \x1b[100m \x1b[100m \x1b[100m \x1b[100m \x1b[0m\n";
  cout << "   ";
  cin >> entry;
  cout << "   \x1b[100m \x1b[43m \x1b[100m \x1b[100m \x1b[100m \x1b[0m\n";
  cout << "   ";
  cin >> entry;
  cout << "   \x1b[43m \x1b[43m \x1b[100m \x1b[42m \x1b[100m \x1b[0m\n";
  cout << "   ";
  cin >> entry;
  cout << "   \x1b[100m \x1b[42m \x1b[42m \x1b[100m \x1b[100m \x1b[0m\n";
  cout << "   ";
  cin >> entry;
  cout << "   \x1b[100m \x1b[42m \x1b[42m \x1b[42m \x1b[43m \x1b[0m\n";
  cout << "   ";
  cin >> entry;
  cout << "   \x1b[42m \x1b[42m \x1b[42m \x1b[42m \x1b[42m \x1b[0m\n";
}