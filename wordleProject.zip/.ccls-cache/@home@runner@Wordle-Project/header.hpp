#include <iostream>
using namespace std;

void doSomething()
{
  cout << "Hello World!";

  return;
}