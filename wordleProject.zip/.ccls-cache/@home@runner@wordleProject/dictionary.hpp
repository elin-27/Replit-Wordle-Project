/*
commonDict.csv is a dictionary of the 855 most common five-letter words in
American English. To avoid generating obscure or unusual words, the word 
generator only uses this dictionary. Source: https://www.wordfrequency.info/

The Dictionary folder contains a dictionary of *most* words in the English 
language. Each letter is stored in its own file in order to omptimze the search.
The specific dictionary file that is opened depends on the word that is entered.
Source: https://www.mso.anu.edu.au/~ralph/OPTED/

The Dictionary class serves as the "dictionary" of the program and has two member functions:
1) inDict() determines if a five letter lowercase word is in the dictionary
    Paramters: five letter string of word (must be lowercase)
    Return: boolean indicating if the letter is in the              dictionary
2) randWord() generates a random word from a separate dictionary
    Parameters: none
    Return: random string of a five letter word
*/

#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

class Dictionary
{   
    public: //function prototypes
        
        //finds if word is in the dictionary
        bool inDict(string); 
        //generate a random five-letter word
        string randWord(); 
};

//inDict() function definition
bool Dictionary::inDict(string word) 
{
    bool inDict = false; //returned variable

    string letter; //the first letter of the word

    //add the first letter of the word to the variable
    letter.push_back(word[0]); 

    //concatenates the first letter to the path
    ifstream fRead("Dictionary Class/Dictionary/" + letter + ".csv");

    //move the index to the end of the file
    fRead.seekg(0, ios::end); 
    
    //calculate the size (number of words)
    //of the file (five letters + '\n' + '\r')
    int size = (fRead.tellg() / 7); 

    //binary search algorithm to look for word in file
    //variables for binary search
    int first = 0, last = size, middle; 
    string currentWord; //word at current index
    while (!inDict && first <= last)
    {
        middle = (first + last) / 2; //calculate middle index
        //move the index to the beggining 
        //of the word at the index = middle
        fRead.seekg(middle * 7, ios::beg); 

        //get word at current index
        //note: linux includes '\r'
        //add '\r' argument for getline()
        getline(fRead, currentWord, '\r'); 

        //binary search comparisons
        if (currentWord == word) inDict = true;        
        else if (currentWord > word) last = middle - 1;
        else first = middle + 1;
    }
    return inDict; //return boolean variable
}

string Dictionary::randWord() //randWord() definition
{    
    string randWord; //returned variable

    //path of dictionary for random word generation
    ifstream fRead("Dictionary Class/commonDict.csv");
    const int MAX = 854; //constant for size of dictionary file

    //seed rng once?
    srand(time(0)); //seed RNG
    rand(); //discard first itereation

    //calculate index of random word
    //five letters plus \n plus \r
    long wrdIndex = (rand() % (MAX + 1)) * 7; 

    //move current index to random index
    fRead.seekg(wrdIndex, ios::beg);
    
    //get word at position wrdIndex
    getline(fRead, randWord, '\r'); 
    return randWord; //return random word as string
}