#include <iostream>
#include <string>
using namespace std;

class Game
{   
    private:
        string alphabetColors[26];
        int *checkInput(string, string);
        string colorFormatter(int []);
        string colorFormatterAlpha(int, char);
        bool isLowerAlpha(string);

    public:
        Game();
        void displayColors(string, string);
        void getUserAns(string &);
        void addLetter(int, char);
        void getUsedLetters();
};

Game::Game()
{
    for (int i = 97; i < 123; i++)
        {
            char ltr = static_cast<char>(i);
            alphabetColors[i - 97].push_back(ltr);
        }
}

int *Game::checkInput(string input, string answer)
{   
    int *ansArr = new int[5];    
    
    for (int i = 0; i < 5; i++)
    {
        if (input[i] == answer[i]) 
        {
            ansArr[i] = 2;
            answer[i] = '-';
               
        }
    }
    for (int j = 0; j < 5; j++)
    {
        int pos = answer.find(input[j]);
        if (ansArr[j] != 2)
        {
            if (pos >= 0 && pos <= 4)
            {
                ansArr[j] = 1;
                answer[pos] = '-';
            }
            else ansArr[j] = 0;
        }
    }
    
    return ansArr;
}

string Game::colorFormatter(int *colorArr)
{
    const string GRAY = "\x1b[100m", 
                 ORANGE = "\x1b[43m",
                 GREEN = "\x1b[42m",
                 RESET = "\x1b[0m";
    
    string str = "\0";

    for (int i = 0; i < 5; i++)
    {
        if (colorArr[i] == 0)
            str.append(GRAY);
        else if (colorArr[i] == 1)
            str.append(ORANGE);
        else if (colorArr[i] == 2)
            str.append(GREEN);

        str.append(" " + RESET);
    }

    return str;
}

string Game::colorFormatterAlpha(int color, char letter)
{
    const string GRAY =   "\x1b[100m", 
                 ORANGE = "\x1b[043m",
                 GREEN =  "\x1b[042m",
                 RESET =  "\x1b[000m";
    
    string str = "";
    
    switch (color)
    {
        case 0:
        str.append(GRAY);
        break;
        case 1:
        str.append(ORANGE);
        break;
        case 2:
        str.append(GREEN);
        break;
    }

    str.append(letter + RESET);
    return str;
}

bool Game::isLowerAlpha(string entry)
{
    bool isLowerAlpha = true;
    for (int i = 0; i < entry.length(); i++)
    {    
        char ltr = entry[i];
        if (!(ltr >= 97 && ltr <= 122))
        {
            isLowerAlpha = false;
            break;
        }
    }
    return isLowerAlpha;
}

void Game::displayColors(string userAns, string correctAns)
{
    int *colorArr = checkInput(userAns, correctAns);
    string output = colorFormatter(colorArr);

    for (int i = 0; i < 5; i++)
    {
        addLetter(colorArr[i], userAns[i]);
    }
    
    //cout << "Here\n";
    //cout << output;
    getUsedLetters();
    //cout << "Here again\n";
    cout << endl;
    
}

void Game::getUserAns(string &userInput)
{
    string input;
    do    
    {
        getline(cin, input);
        
        if (!isLowerAlpha(input)) 
            cout << "Error: Input must be alphabetical and lowercase.\n";
        if (input.length() != 5)
            cout << "Error: Input must be five characters.\n";
        if (input.length() != 5 || !isLowerAlpha(input))
            cout << "Please try again.\n";
    }
    while (!isLowerAlpha(input) || input.length() != 5);
    
    userInput = input;
    return;
}

void Game::addLetter(int color, char letter)
{
    string coloredLetter = colorFormatterAlpha(color, letter);
    int letterPos = static_cast<int>(letter);
    alphabetColors[letterPos - 97] = coloredLetter;
}

void Game::getUsedLetters()
{
    for (int i = 0; i < 26; i++)
    {
        cout << alphabetColors[i] << " ";
    } 
    return;
}