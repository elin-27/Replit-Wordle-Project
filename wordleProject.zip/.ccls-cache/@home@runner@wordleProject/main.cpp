#include <iostream>
#include <string>
#include "game.hpp"
#include "dictionary.hpp"
using namespace std;

int main() {
    Game wordle;
    Dictionary dictionary;
    string userAns;


    string correctAns = dictionary.randWord();

    cout << "     Wordle\n";
    cout << "----------------\n";

    for (int wrds = 0; wrds < 6; wrds++)
    {
        do
        {
            wordle.getUserAns(userAns);
            if (!dictionary.inDict(userAns))
                cout << "Error: Input not in dictionary.\n";
        }
        while (!dictionary.inDict(userAns));
        
        wordle.displayColors(userAns, correctAns);
        
        if (userAns == correctAns)
        {
            cout << "Congratulations!\n";
            break;
        }
        if (wrds == 5)
            cout << "The correct answer is: " << correctAns << endl;
    }
    
    return 0;
}